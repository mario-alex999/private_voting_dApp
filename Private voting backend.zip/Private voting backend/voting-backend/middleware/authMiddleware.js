const jwt = require("jsonwebtoken");

const protect = (req, res, next) => {
    let token;

    // Check if token is passed in Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
        try {
            // Extract token from Authorization header
            token = req.headers.authorization.split(" ")[1];

            // Verify token
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            // Attach the user information to the request
            req.user = decoded;
            next();  // Continue to the next middleware/route
        } catch (err) {
            return res.status(401).json({ message: "Not authorized, token failed" });
        }
    }

    if (!token) {
        return res.status(401).json({ message: "No token, Not authorized" });
    }
};

module.exports = protect;