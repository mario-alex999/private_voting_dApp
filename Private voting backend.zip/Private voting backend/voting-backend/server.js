// const express = require("express");
// const mongoose = require("mongoose");
// const dotenv = require("dotenv");

// dotenv.config();
// const app = express();
// app.use(express.json());

// // Test route
// app.get("/", (req, res) => res.send("Backend is working!"));

// // User routes
// const userRoutes = require("./routes/userRoutes");
// app.use("/api/users", userRoutes);

// // console.log("Loading user routes...");
// // const userRoutes = require("./routes/userRoutes");
// // console.log("User routes loaded successfully");

// // Connect to MongoDB if URI exists
// if (process.env.MONGO_URI) {
//     mongoose.connect(process.env.MONGO_URI, {
//         useNewUrlParser: true,
//         useUnifiedTopology: true,
//     })
//     .then(() => console.log("MongoDB connected"))
//     .catch((err) => console.log("MongoDB connection error:", err));
// } else {
//     console.log("No MongoDB URI found. Skipping DB connection for now.");
// }

// // Start server
// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");

dotenv.config();
const app = express();
app.use(express.json());

// Routes
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);

// Connect to MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("MongoDB Atlas connected"))
    .catch((err) => console.log("MongoDB connection error:", err));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));