// console.log("userRoutes file loaded...");

// const express = require("express");
// const router = express.Router();
// //const { registerUser, getAllUsers } = require("../controllers/userController");
// const registerUser = (req, res) => res.send("Register works");
// const getAllUsers = (req, res) => res.send("Get users works");

// // Register new user
// router.post("/register", registerUser);

// // Get all users
// router.get("/", getAllUsers);

// module.exports = router;

// const express = require("express");
// const router = express.Router();

// // TEMP: dummy functions to check routing
// const registerUser = (req, res) => res.send("Register works");
// const getAllUsers = (req, res) => res.send("Get users works");

// // Routes
// router.post("/register", registerUser);
// router.get("/", getAllUsers);


const express = require("express");
const router = express.Router();

// Import your real controller functions
const { registerUser, loginUser, getAllUsers, vote } = require("../controllers/userControllers");
const protect = require("../middleware/authMiddleware");
// Routes
router.post("/register", registerUser);  // Register new user
router.post("/login", loginUser);        // Login user            
router.get("/", protect, getAllUsers);  // Get all users
router.post("/vote", protect, vote); // vote route

module.exports = router;