// console.log("userController loaded...");

// const User = require("../models/User");
// const bcrypt = require("bcryptjs"); // <-- import bcrypt

// // Register a user
// const registerUser = async (req, res) => {
//     try {
//         const { username, email, password } = req.body;

//         // Hash the password
//         const hashedPassword = await bcrypt.hash(password, 10); // 10 salt rounds

//         // Save user with hashed password
//         const user = new User({ username, email, password: hashedPassword });
//         await user.save();

//         res.status(201).json({ message: "User registered successfully", user });
//     } catch (err) {
//         res.status(500).json({ error: err.message });
//     }
// };

// // Get all users
// const getAllUsers = async (req, res) => {
//     try {
//         const users = await User.find();
//         res.json(users);
//     } catch (err) {
//         res.status(500).json({ error: err.message });
//     }
// };

// module.exports = { registerUser, getAllUsers };

// const User = require("../models/User");
// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");

// // Register a user
// const registerUser = async (req, res) => {
//     try {
//         const { username, email, password } = req.body;

//         // Check if user already exists
//         const existingUser = await User.findOne({ email });
//         if (existingUser) {
//             return res.status(400).json({ error: "User already exists" });
//         }

//         // Hash password
//         const salt = await bcrypt.genSalt(10);
//         const hashedPassword = await bcrypt.hash(password, salt);

//         // Save user
//         const user = new User({
//             username,
//             email,
//             password: hashedPassword
//         });
//         await user.save();

//         res.status(201).json({
//     message: "User registered successfully",
//     user: {
//         id: user._id,
//         username: user.username,
//         email: user.email
//     }
// });
//     } catch (err) {
//         //console.log(err);
//         res.status(500).json({ error: err.message });
//     }
// };
// //login user
// const loginUser = async (req, res) => {
//     try {
//         const { email, password } = req.body;

//         const user = await User.findOne({ email });
//         if (!user) {
//             return res.status(400).json({ error: "Invalid email or password" });
//         }

//         const isMatch = await bcrypt.compare(password, user.password);
//         if (!isMatch) {
//             return res.status(400).json({ error: "Invalid email or password" });
//         }

//         // Generate JWT token
//         const token = jwt.sign(
//             { id: user._id },
//             process.env.JWT_SECRET,
//             { expiresIn: "1d" }
//         );

//         res.status(200).json({
//             message: "Login successful",
//             token,  // Make sure this is included
//             user: {
//                 id: user._id,
//                 username: user.username,
//                 email: user.email,
//                 voted: user.voted
//             }
//         });

//     } catch (err) {
//         res.status(500).json({ error: err.message });
//     }
// };
// // Get all users
// const getAllUsers = async (req, res) => {
//     try {
//         const users = await User.find().select("-password");
//         res.json(users);
//     } catch (err) {
//         res.status(500).json({ error: err.message });
//     }
// };

// module.exports = { registerUser, loginUser, getAllUsers };

const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ------------------ REGISTER USER ------------------
const registerUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Save user
    const user = new User({
      username,
      email,
      password: hashedPassword,
    });
    await user.save();

    res.status(201).json({ message: "User registered successfully", user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ------------------ LOGIN USER ------------------
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    // Generate JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        voted: user.voted,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ------------------ GET ALL USERS ------------------
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password"); // hide password
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ------------------ VOTE ------------------
const vote = async (req, res) => {
  try {
    const userId = req.user.id; // set by JWT middleware
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    if (user.voted) {
      return res.status(400).json({ error: "You have already voted" });
    }

    // Process vote (e.g., candidate selection could be in req.body)
    user.voted = true;
    await user.save();

    res.status(200).json({ message: "Vote recorded successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { registerUser, loginUser, getAllUsers, vote };